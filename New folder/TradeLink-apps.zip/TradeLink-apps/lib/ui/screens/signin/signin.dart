import 'package:flutter/material.dart';
import 'package:selendra_marketplace_app/ui/screens/signin/components/body.dart';

class SignIn extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Body(),
      ),
    );
  }
}
