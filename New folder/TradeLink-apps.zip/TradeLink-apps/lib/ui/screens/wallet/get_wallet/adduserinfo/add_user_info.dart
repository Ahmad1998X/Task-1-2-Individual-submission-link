import 'package:flutter/material.dart';
import 'add_user_info_body.dart';

class AddUserInfoScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}