import 'package:flutter/material.dart';
import 'user_info_body.dart';

class UserInfoScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}