class NotificationModel {
  String img;
  String title;
  String time;

  NotificationModel(this.img, this.title, this.time);
}
