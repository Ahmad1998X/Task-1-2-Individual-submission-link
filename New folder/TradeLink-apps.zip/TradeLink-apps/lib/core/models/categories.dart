class Categories {
  String title;
  String img;

  Categories({this.title, this.img});
}

List<Categories> category = [
  Categories(title: 'Cereals', img: 'images/barley.png'),
  Categories(title: 'Fruit', img: 'images/fruits.png'),
  Categories(title: 'Vegetable', img: 'images/vegetable.png'),
  Categories(title: 'Meat', img: 'images/meat.png'),
  Categories(title: 'Fish', img: 'images/fish.png'),
  Categories(title: 'Others', img: 'images/others.png'),
];
