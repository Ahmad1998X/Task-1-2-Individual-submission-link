enum ConnectivityStatus{
  CELLULAR,
  WIFI,
  OFFLINE
}