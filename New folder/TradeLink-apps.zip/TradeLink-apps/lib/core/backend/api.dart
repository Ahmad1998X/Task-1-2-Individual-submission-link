class SelendraApi {
  /* Zeetomic api image upload */
  final apiPostImage = "http://s3.selendra.com";

  // final url = "https://testnet-api.selendra.com/pub/v1";

  /* Zeetomic OCR */
  final urlOCR = "https://zocr.zeetomic.com/pushimage";

  // "https://testnet-api.selendra.com/pub/v1 = Selendra wallet
  final String api = "https://testnet-api.selendra.com/sdm/v1";
  final String walletAPI = "https://testnet-api.selendra.com/pub/v1";
}
