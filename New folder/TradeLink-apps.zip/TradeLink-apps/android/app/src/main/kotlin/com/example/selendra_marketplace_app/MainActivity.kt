package com.example.selendra_marketplace_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
  

}




